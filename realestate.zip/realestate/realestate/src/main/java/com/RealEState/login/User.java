package com.RealEState.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.RealEState.admin.ManagePassword;

@SuppressWarnings("unused")
public class User {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String firstName;
	private String lastName;

	private String email;
	private String password;
	private String address;
	private int otp;
	private int flag;

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	private String state;
	private long mobileNo;

	private int isAdmin;

	public int getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(int isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int insert(Connection con) throws SQLException {

		String sql = "INSERT INTO `realestate`.`user`(`first_name`,`last_name`,`email`,`password`,`mobile_no`,`address`,`state`) ";
		sql += "VALUES(?,?,?,?,?,?,?)";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setString(++i, firstName);
		ps.setString(++i, lastName);
		ps.setString(++i, email);
		ps.setString(++i, password);
		ps.setLong(++i, mobileNo);
		ps.setString(++i, address);
		ps.setString(++i, state);

		int inserted = ps.executeUpdate();
		ps.close();
		return inserted;
	}

	public boolean validateUser(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "Select count(*)as userExist from user where email=? and password=? ";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		ps.setString(++i, email);
		ps.setString(++i, password);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			count = Integer.parseInt(rs.getString("userExist"));
		}
		System.out.println("count====>" + count);

		ps.close();
		if (count > 0) {

			return true;

		}

		return false;
	}

	public User getUserById(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "Select  * from user where id=?";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, id);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			id = rs.getInt("id");
			email = rs.getString("email");
			firstName = rs.getString("first_name");
			lastName = rs.getString("last_name");
			address = rs.getString("address");
			mobileNo = rs.getLong("mobile_no");
			state = rs.getString("state");
			isAdmin = rs.getInt("admin");
		}

		return this;
	}

	public User getUser(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "Select  * from user where email=? and password=? ";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		ps.setString(++i, email);
		ps.setString(++i, password);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			id = rs.getInt("id");
			email = rs.getString("email");
			firstName = rs.getString("first_name");
			lastName = rs.getString("last_name");
			address = rs.getString("address");
			mobileNo = rs.getLong("mobile_no");
			state = rs.getString("state");
			isAdmin = rs.getInt("admin");
		}

		return this;
	}

	public List<User> getUserList(Connection con) throws SQLException {

		String sql = "Select  * from user";
		List<User> userList = new ArrayList<>();

		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		System.out.println("SQL  select******===>" + ps.toString());

		ResultSet rs = ps.executeQuery();
		User u;
		while (rs.next()) {
			u = new User();

			u.setId(rs.getInt("id"));

			u.setEmail(rs.getString("email"));
			u.setAddress(rs.getString("address"));
			u.setFirstName(rs.getString("first_name"));
			u.setIsAdmin(rs.getInt("admin"));
			u.setLastName(rs.getString("last_name"));
			u.setMobileNo(rs.getLong("mobile_no"));
			u.setState(rs.getString("state"));
			userList.add(u);

		}

		return userList;
	}

	public int delete(Connection con) throws SQLException {
		String sql = "delete  from user where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.execute();
		ps.close();

		return 0;
	}

	public int update(Connection con) throws SQLException {

		String Sql = "";
		if (flag == 1) {

			Sql = "UPDATE user Set first_name=?,last_name=?,email=?,address=?,mobile_no=?,state=?,admin=? ,password=? where id=? ";
		} else {

			Sql = "UPDATE user Set first_name=?,last_name=?,email=?,address=?,mobile_no=?,state=?,password=? where id=? ";

		}

		PreparedStatement ps = con.prepareStatement(Sql);
		int i = 0;
		ps.setString(++i, firstName);
		ps.setString(++i, lastName);
		ps.setString(++i, email);
		ps.setString(++i, address);
		ps.setLong(++i, mobileNo);
		ps.setString(++i, state);

		if (flag == 1) {
			ps.setInt(++i, isAdmin);
		}
		ps.setString(++i, password);
		ps.setInt(++i, id);
		return ps.executeUpdate();
	}

	public int updateOtp(Connection con) throws SQLException {

		String Sql = "UPDATE user Set otp=? where email=? ";
		PreparedStatement ps = con.prepareStatement(Sql);
		int i = 0;

		ps.setInt(++i, otp);
		ps.setString(++i, email);

		System.out.println("update===>" + ps.toString());

		return ps.executeUpdate();
	}

	public int updatePassWord(Connection con) throws SQLException {

		String Sql = "UPDATE user Set password=? where email=? and otp=? ";
		PreparedStatement ps = con.prepareStatement(Sql);
		int i = 0;

		ps.setString(++i, password);
		ps.setString(++i, email);
		ps.setInt(++i, otp);

		System.out.println("update===>" + ps.toString());
		int k = ps.executeUpdate();
		return k;
	}

	
	public boolean isUserAvaible(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "Select count(*)as userExist from user where email=?";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		ps.setString(++i, email);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			count = Integer.parseInt(rs.getString("userExist"));
		}
		System.out.println("count===>"+ps.toString());
		System.out.println("count====>" + count);

		ps.close();
		if (count > 0) {

			return true;

		}

		return false;
	}
	public void deleteUser(Connection con) throws SQLException {

		String sql = "delete  from user where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.execute();

		ps.close();

	}

	public int checkOtp(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "Select count(*)as validOtp  from user where email=? and otp=?";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;

		ps.setString(++i, email);
		ps.setInt(++i, otp);

		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			count = Integer.parseInt(rs.getString("validOtp"));
		}
		System.out.println("count===>" + ps.toString());
		System.out.println("count====>" + otp);

		ps.close();
		return count;
	}

}
