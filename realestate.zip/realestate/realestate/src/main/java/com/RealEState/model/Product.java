package com.RealEState.model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.model.Product;

/**
 * Servlet implementation class Product
 */
public class Product {

	private int id;
	private String product_name;
	private String product_image;
	private String product_image_alterd_name;
	private int price;
	private String product_details;
	private String product_type;

	Product(ResultSet rs) throws SQLException {

		fillObject(rs);

	}

	public Product() {

	}

	private void fillObject(ResultSet rs) throws SQLException {
		// TODO Auto-generated method stub
		if (rs.next()) {
			id = rs.getInt("id");
			product_name = rs.getString("product_name");
			product_image = rs.getString("product_image");
			product_image_alterd_name = rs.getString("product_image_alterd_name");
			price = rs.getInt("price");
			product_details = rs.getString("product_details");
			product_type = rs.getString("product_type");
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_image() {
		return product_image;
	}

	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}

	public String getProduct_image_alterd_name() {
		return product_image_alterd_name;
	}

	public void setProduct_image_alterd_name(String product_image_alterd_name) {
		this.product_image_alterd_name = product_image_alterd_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getProduct_details() {
		return product_details;
	}

	public void setProduct_details(String product_details) {
		this.product_details = product_details;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public List<Product> getProducts(Connection con) throws SQLException {

		List<Product> productList = new ArrayList<>();

		Product p;
		String sql = "Select * from products";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			p = new Product();

			p.setId(rs.getInt("id"));
			p.setPrice(rs.getInt("price"));
			p.setProduct_details(rs.getString("product_details"));
			p.setProduct_image(rs.getString("product_image"));
			p.setProduct_image_alterd_name(rs.getString("product_image_alterd_name"));

			p.setProduct_name(rs.getString("product_name"));
			p.setProduct_type(rs.getString("product_type"));
			
			productList.add(p);

		}
		System.out.println("size====>" + productList.size());

		ps.close();

		return productList;

	}

	public int insert(Connection con) throws SQLException {

		String sql = "INSERT INTO products (product_name,product_image,product_image_alterd_name,price,product_details,product_type)";
		sql += "VALUES(?,?,?,?,?,?)";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setString(++i, product_name);
		ps.setString(++i, product_image);
		ps.setString(++i, product_image_alterd_name);
		ps.setInt(++i, price);
		ps.setString(++i, product_details);
		ps.setString(++i, product_type);

		return ps.executeUpdate();

	}

	public int checkProductExist(Connection con) throws SQLException {

		Product p;
		String sql = "Select count(*) as countproduct from products where id=?";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);

		ResultSet rs = ps.executeQuery();
		if (rs.next()) {

			count = Integer.parseInt(rs.getString("countproduct"));
		}

		return count;
	}

	public Product getProduct(Connection con) throws SQLException {

		String sql = "Select *  from products where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);

		ResultSet rs = ps.executeQuery();
		this.fillObject(rs);

		ps.close();

		return this;
	}

	public void deleteProduct(Connection con) throws SQLException {

		String sql = "delete  from products where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.execute();
		
		System.out.println("===>del===>"+ps.toString());

		ps.close();

	}

	// UPDATE products
	// (product_name,product_image,product_image_alterd_name,price,product_details,product_type)";

	public int update(Connection con) throws SQLException {

		String Sql = "UPDATE products Set product_name=?,product_image=?,product_image_alterd_name=?,price=?,product_details=?,product_type=? where id=? ";
		PreparedStatement ps = con.prepareStatement(Sql);
		int i = 0;
		ps.setString(++i, product_name);
		ps.setString(++i, product_image);
		ps.setString(++i, product_image_alterd_name);
		ps.setInt(++i, price);
		ps.setString(++i, product_details);
		ps.setString(++i, product_type);
		ps.setInt(++i, id);
		return ps.executeUpdate();
	}

	public List<Product> getUniqueProducts(Connection con) throws SQLException {

		List<Product> productList = new ArrayList<>();

		Product p;
		String sql = "Select DISTINCT product_type  from products ";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			p = new Product();
			/*
			 * id=rs.getInt("id"); product_name= rs.getString("product_name");
			 * product_image=rs.getString("product_image");
			 * product_image_alterd_name=rs.getString("product_image_alterd_name"); price
			 * =rs.getInt("price"); product_details=rs.getString("product_details");
			 * product_type=rs.getString("product_type");
			 */

			p.setId(rs.getInt("id"));
			p.setPrice(rs.getInt("price"));
			p.setProduct_details(rs.getString("product_details"));
			p.setProduct_image(rs.getString("product_image"));
			p.setProduct_image_alterd_name(rs.getString("product_image_alterd_name"));

			p.setProduct_name(rs.getString("product_name"));
			p.setProduct_type(rs.getString("product_type"));
			productList.add(p);

		}
		System.out.println("count====>" + count);

		ps.close();

		return productList;

	}

	public List<Product> getSpecailProducts(Connection con) throws SQLException {

		List<Product> productList = new ArrayList<>();

		Product p;
		String sql = "Select * from products where product_type in (2,4,5) ";

		System.out.println("SQL  select===>" + sql);
		int count = 0;
		PreparedStatement ps = con.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			p = new Product();
			/*
			 * id=rs.getInt("id"); product_name= rs.getString("product_name");
			 * product_image=rs.getString("product_image");
			 * product_image_alterd_name=rs.getString("product_image_alterd_name"); price
			 * =rs.getInt("price"); product_details=rs.getString("product_details");
			 * product_type=rs.getString("product_type");
			 */

			p.setId(rs.getInt("id"));
			p.setPrice(rs.getInt("price"));
			p.setProduct_details(rs.getString("product_details"));
			p.setProduct_image(rs.getString("product_image"));
			p.setProduct_image_alterd_name(rs.getString("product_image_alterd_name"));

			p.setProduct_name(rs.getString("product_name"));
			p.setProduct_type(rs.getString("product_type"));
			productList.add(p);

		}
		System.out.println("count====>" + count);

		ps.close();

		return productList;

	}

}
