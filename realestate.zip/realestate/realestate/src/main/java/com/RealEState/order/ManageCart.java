package com.RealEState.order;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.RealEState.database.DbConnection;
import com.RealEState.login.User;
import com.RealEState.model.Cart;
import com.RealEState.model.Product;

/**
 * Servlet implementation class ManageCart
 */
@WebServlet("/ManageCart")
public class ManageCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	DbConnection dbConnecion;
	User currentuser;

	public ManageCart() {
		super();
		try {
			con = dbConnecion.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====>" + currentuser.getFirstName());
		String action = request.getParameter("action");
		System.out.println("action==>" + action);
		switch (action) {
		case "addTocart":
			addTOcart(request, response);
			break;
		case "getCartItems":
			getCartItmes(request, response);
			break;
		case "deleteCartItems":
			deleteCartItmes(request, response);
			break;

		case "deleteCart":
			deleteCart(request, response);
			break;

		case "updateQty":
			updateQty(request, response);
			break;

		default:

			break;

		}

		System.out.println("hello  get");

	}

	public void deleteCart(HttpServletRequest request, HttpServletResponse response) {
		Cart c = new Cart();

		c.setUserID(currentuser.getId());

		try {

			c.deleteCart(con);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void updateQty(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub

		String productId = request.getParameter("productId");

		String imagesPath = request.getContextPath() + "//webapp//products//";
		StringBuffer html = new StringBuffer();

		int total = 0;
		Cart c = new Cart();
		c.setUserID(currentuser.getId());

		try {

			int qty = 0;

			qty = Integer.parseInt(request.getParameter("qty"));
			c.setProductId(Integer.parseInt(productId));
			c.setUserID(currentuser.getId());

			int itemCount = c.getCount(con);

			System.out.println("===>" + itemCount);

			if (itemCount >= 1) {

				c.setQty(qty);
				c.update(con);

			}

			List<Cart> itemList = c.getCartDetails(con);

			Product p = new Product();

			List<Product> productList = p.getProducts(con);

			for (Cart item : itemList) {

				for (Product prod : productList) {

					if (item.getProductId() == prod.getId()) {

						System.out.println("name " + prod.getProduct_name());

						html.append("<div class=\"container-fluid>");

						html.append("<img src=\"" + imagesPath + prod.getProduct_image()
								+ "\"  alt=\"\" height=\"50px\" width=\"50px\">");
						html.append("<div class=\"content\">");
						html.append("<h3>" + prod.getProduct_name() + "</h3>");
						html.append("<span> quantity : </span>");
						html.append("<input type=\"number\"  value=\"" + item.getQty() + "\" id=\""
								+ item.getProductId() + "\" onmouseout=\"JavaScript:return updateQty("
								+ item.getProductId() + ")\"><br>");
						// html.append("<input type=\"number\" name=\"\" value=\""+item.getQty()+"\"
						// id=\"\"><br>");

						html.append("<span> price : </span>");
						html.append("<span class=\"price\">" + prod.getPrice() + "</span></div>");

						html.append("<a href=\"#\" onClick=removeItem(" + item.getProductId() + ")> remove</a></div>");

						int price = prod.getPrice() * item.getQty();
						total = total + price;

					}
					// System.out.println("html===>"+html);

				}
			}
			html.append("<div class=\"cart-total\">");

			html.append(" <h3 class=\"title\"> cart total </h3>");

			html.append("<div class=\"box\">");

			html.append("<h3 class=\"subtotal\">" + " subtotal :" + "<span>$" + total + "</span> </h3>");
			html.append("<h3 class=\"total\">" + " total : " + "<span>" + total + "</span> </h3>");

			html.append(
					"<a href=\"#\" class=\"btn\"  onClick=buyNow()>" + "proceed to checkout" + "</a> </div> </div>");

			response.getWriter().write(html.toString());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// response.getWriter().write("hello added to cart==>"+productId);

	}

	private void deleteCartItmes(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub

		int itemId = Integer.parseInt(request.getParameter("itemId"));

		System.out.println("delete cart ===---=>");
		StringBuffer html = new StringBuffer();
		Cart c = new Cart();
		c.setProductId(itemId);
		c.setUserID(currentuser.getId());

		try {
			c.deleteCartItem(con);

			List<Cart> itemList = c.getCartDetails(con);

			Product p = new Product();

			List<Product> productList = p.getProducts(con);

			int total = 0;

			for (Cart item : itemList) {

				for (Product prod : productList) {

					if (item.getProductId() == prod.getId()) {

						System.out.println("name " + prod.getProduct_name());

						html.append("<div class=\"container-fluid>");

						html.append("<img src=\"" + prod.getProduct_image()
								+ "\"  alt=\"\" height=\"50px\" width=\"50px\">");
						html.append("<div class=\"content\">");
						html.append("<h3>" + prod.getProduct_name() + "</h3>");
						html.append("<span> quantity : </span>");
						// html.append("<input type=\"number\" name=\"\" value=\""+item.getQty()+"\"
						// id=\""+item.getProductId()+"\"
						// onClick=\"updateQty("+item.getProductId()+"\"\")><br>");
						html.append("<input type=\"number\"  value=\"" + item.getQty() + "\" id=\""
								+ item.getProductId() + "\" onmouseout=\"JavaScript:return updateQty("
								+ item.getProductId() + ")\"><br>");
						html.append("<span> price : </span>");
						html.append("<span class=\"price\">" + prod.getPrice() + "</span></div>");

						html.append("<a href=\"#\" onClick=removeItem(" + item.getProductId() + ")> remove</a></div>");
						int price = prod.getPrice() * item.getQty();
						total = total + price;

					}
					System.out.println("html===>" + html);

				}
			}
			html.append("<div class=\"cart-total\">");

			html.append(" <h3 class=\"title\"> cart total </h3>");

			html.append("<div class=\"box\">");
			html.append("<h3 class=\"subtotal\">" + " subtotal :" + "<span>$" + total + "</span> </h3>");
			html.append("<h3 class=\"total\">" + " total : " + "<span>" + total + "</span> </h3>");

			/*
			 * html.append("<h3 class=\"subtotal\">"+" subtotal :"+"<span>$200</span> </h3>"
			 * ); html.append("<h3 class=\"total\">"+" total : "+"<span>$200</span> </h3>");
			 */
			html.append(
					"<a href=\"#\" class=\"btn\"  onClick=buyNow()>" + "proceed to checkout" + "</a> </div> </div>");

			response.getWriter().write(html.toString());

			// System.out.println("Size===>"+itemList.size());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void getCartItmes(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		// http://localhost:8080/CafeZone/Resources/image/coffee2.jpg

		String imagesPath = request.getContextPath() + "//webapp//products//";
		StringBuffer html = new StringBuffer();

		int total = 0;
		Cart c = new Cart();
		c.setUserID(currentuser.getId());
		try {
			List<Cart> itemList = c.getCartDetails(con);

			Product p = new Product();

			List<Product> productList = p.getProducts(con);

			for (Cart item : itemList) {

				for (Product prod : productList) {

					if (item.getProductId() == prod.getId()) {

						System.out.println("name " + prod.getProduct_name());

						html.append("<div class=\"container-fluid>");

						html.append("<img src=\"" + imagesPath + prod.getProduct_image()
								+ "\"  alt=\"\" height=\"50px\" width=\"50px\">");
						html.append("<div class=\"content\">");
						html.append("<h3>" + prod.getProduct_name() + "</h3>");
						html.append("<span> quantity : </span>");
						html.append("<input type=\"number\"  value=\"" + item.getQty() + "\" id=\""
								+ item.getProductId() + "\" onmouseout=\"JavaScript:return updateQty("
								+ item.getProductId() + ")\"><br>");
						// html.append("<input type=\"number\" name=\"\" value=\""+item.getQty()+"\"
						// id=\"\"><br>");

						html.append("<span> price : </span>");
						html.append("<span class=\"price\">" + prod.getPrice() + "</span></div>");

						html.append("<a href=\"\" onClick=removeItem(" + item.getProductId() + ")> remove</a></div>");

						int price = prod.getPrice() * item.getQty();
						total = total + price;

					}
					System.out.println("html===>" + html);

				}
			}
			html.append("<div class=\"cart-total\">");

			html.append(" <h3 class=\"title\"> cart total </h3>");

			html.append("<div class=\"box\">");

			html.append("<h3 class=\"subtotal\">" + " subtotal :" + "<span>$" + total + "</span> </h3>");
			html.append("<h3 class=\"total\">" + " total : " + "<span>" + total + "</span> </h3>");
			html.append(
					"<a href=\"#\" class=\"btn\"  onClick=buyNow()>" + "proceed to checkout" + "</a> </div> </div>");
			// html.append("<a
			// href=\""+request.getContextPath()+"/ManageOrders?action=showOrders\"
			// class=\"btn\">"+"proceed to checkout"+"</a> </div> </div>");

			response.getWriter().write(html.toString());

			// System.out.println("Size===>"+itemList.size());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void addTOcart(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String productId = request.getParameter("productId");

		Cart c = new Cart();

		try {

			int qty = 0;
			c.setProductId(Integer.parseInt(productId));
			c.setUserID(currentuser.getId());

			int itemCount = c.getCount(con);

			System.out.println("===>" + itemCount);
			if (itemCount == 0) {
				c.setQty(1);
				c.insert(con);
			}

			if (itemCount >= 1) {

				qty = c.getQty(con);
				qty = qty + 1;

				c.setQty(qty);
				c.update(con);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// getCartItmes(request, response);
		response.getWriter().write("hello added to cart==>" + productId);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("hello  post");
		doGet(request, response);

	}

}
