package com.RealEState.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.database.DbConnection;
import com.RealEState.login.Info;

/**
 * Servlet implementation class AdminInfo
 */
@WebServlet("/AdminInfo")
public class AdminInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;

	DbConnection dbConnecion;

	@SuppressWarnings("static-access")
	public AdminInfo() {
		super();
		// TODO Auto-generated constructor stub

		try {

			con = dbConnecion.getConnection();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String msg = request.getParameter("msg");

		System.out.println(name + "=====" + email + "======" + msg);

		Info info = new Info();

		info.setEmail(email);
		info.setName(name);
		info.setMsg(msg);

		try {

			@SuppressWarnings("unused")
			int inserted = info.insert(con);

			System.out.println("Data Send" + inserted);

			
			RequestDispatcher rd = request.getRequestDispatcher("/productcatalog.jsp");
	 
	 rd.forward(request, response);
	

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * protected void doPost(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub doGet(request, response); }
	 */

}
