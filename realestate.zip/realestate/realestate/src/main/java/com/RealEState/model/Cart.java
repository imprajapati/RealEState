package com.RealEState.model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.model.Cart;


public class Cart {

	private int id;
	private int productId;
	private int qty;
	private int price;
	private int userID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public int insert(Connection con) throws SQLException {

		String sql = "INSERT INTO cart (productId,qty,userId) values(?,?,?)";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, productId);
		ps.setInt(++i, qty);
		ps.setInt(++i, userID);

		System.out.println("insert====" + ps.toString());
		return ps.executeUpdate();
	}

	public int getCount(Connection con) throws SQLException {

		int itemCount = 0;
		String sql = "SELECT count(*)as itemCount FROM  cart where userId=? and productId =?";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, userID);
		ps.setInt(++i, productId);
		ResultSet rs = ps.executeQuery();

		if (rs.next()) {

			itemCount = rs.getInt("itemCount");

			System.out.println("itemCount=----sql==>" + itemCount);
		}

		ps.close();
		return itemCount;
	}

	public int getQty(Connection con) throws SQLException {

		int qty = 0;
		String sql = "SELECT qty FROM  cart where userId=? and productId=? ";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, userID);
		ps.setInt(++i, productId);
		ResultSet rs = ps.executeQuery();
		System.out.println("getqty=====>====" + ps.toString());

		if (rs.next()) {

			qty = rs.getInt("qty");

		}

		ps.close();
		return qty;
	}

	public void update(Connection con) throws SQLException {
		// TODO Auto-generated method stub

		String sql = "UPDATE cart SET  qty =? where userId=? and productId=? ";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, qty);
		ps.setInt(++i, userID);
		ps.setInt(++i, productId);

		ps.executeUpdate();
		ps.close();
	}

	public List<Cart> getCartDetails(Connection con) throws SQLException {

		List<Cart> cartItemList = new ArrayList<>();
		Cart c;

		String sql = "SELECT * FROM  cart where userId=?";

		PreparedStatement ps = con.prepareStatement(sql);
		int i = 0;
		ps.setInt(++i, userID);
		ResultSet rs = ps.executeQuery();
		System.out.println("getqty=====>====" + ps.toString());

		while (rs.next()) {
			c = new Cart();
			c.setQty(rs.getInt("qty"));
			c.setProductId(rs.getInt("productId"));
			c.setUserID(rs.getInt("userID"));
			cartItemList.add(c);

		}

		return cartItemList;
	}
	public void deleteCartItem(Connection con) throws SQLException {
int i=0;
		String sql = "delete  from cart where productId=? and  userId=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(++i, productId);
		ps.setInt(++i, userID);
		ps.execute();
	

		ps.close();

		
	}
	
	public void deleteCart(Connection con) throws SQLException {
		int i=0;
				String sql = "delete  from cart where  userId=?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(++i, userID);
				ps.execute();
			

				ps.close();

				
			}
	
}
