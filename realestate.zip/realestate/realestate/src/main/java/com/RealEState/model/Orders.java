package com.RealEState.model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.model.Orders;
import com.RealEState.model.Product;

/**
 * Servlet implementation class Orders
 */public class Orders {

		private int id;
		private String productName;
		private int price;
		private Timestamp createdAt;
		private int userId;
		private int qty;
		private int total;
		private int tax;
		private String orderStatus;
		private String userName;
		
		private Timestamp modifiedAt;
		

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public int getProduct_type() {
			return product_type;
		}

		public void setProduct_type(int product_type) {
			this.product_type = product_type;
		}

		private int product_type;
		// cancled and delivered and inTransit
		private int productId;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public Timestamp getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(Timestamp createdAt) {
			this.createdAt = createdAt;
		}

		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

		public int getQty() {
			return qty;
		}

		public void setQty(int qty) {
			this.qty = qty;
		}

		public int getTotal() {
			return total;
		}

		public void setTotal(int total) {
			this.total = total;
		}

		public int getTax() {
			return tax;
		}

		public void setTax(int tax) {
			this.tax = tax;
		}

		public String getOrderStatus() {
			return orderStatus;
		}

		public void setOrderStatus(String orderStatus) {
			this.orderStatus = orderStatus;
		}

		public int getProductId() {
			return productId;
		}

		public void setProductId(int productId) {
			this.productId = productId;
		}

		public int insert(Connection con) throws SQLException {

			String sql = "INSERT INTO `realestate`.`orders`(`product_type`,`qty`,`price`,`userId`,`product_name`,`productId`,`orderStatus`,`orderAt`) values(?,?,?,?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(sql);
			int i = 0;
			ps.setInt(++i, product_type);
			ps.setInt(++i, qty);
			ps.setInt(++i, price);
			ps.setInt(++i, userId);
			ps.setString(++i, productName);
			ps.setInt(++i, productId);
			ps.setString(++i, orderStatus);
			ps.setTimestamp(++i, createdAt);

			System.out.println("insert====" + ps.toString());
			return ps.executeUpdate();
		}

		public List<Orders> getOrders(Connection con) throws SQLException {
			List<Orders> orderList = new ArrayList<>();

			Orders o;
			Product p;
			String sql = "SELECT * FROM orders  ord join user u on ord.userId=u.id";

			System.out.println("SQL  select===>" + sql);
			int count = 0;
			int i = 0;
			PreparedStatement ps = con.prepareStatement(sql);
		
			
			System.out.println("sql==========>"+ps.toString());
			
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				o = new Orders();

				o.setId(rs.getInt("id"));
				o.setOrderStatus(rs.getString("orderStatus"));
				o.setPrice(rs.getInt("price"));
				o.setProduct_type(rs.getInt("product_type"));
				o.setProductId(rs.getInt("productId"));
				o.setProductName(rs.getString("product_name"));
				o.setQty(rs.getInt("qty"));
				o.setUserId(rs.getInt("userId"));
				o.setUserName(rs.getString("first_name")+" "+rs.getString("last_name"));
				o.setCreatedAt(rs.getTimestamp("orderAt"));
				o.setModifiedAt(rs.getTimestamp("modifiedAt"));

				orderList.add(o);
			}

			return orderList;
		}
		
		public int updateOrderStatus(Connection con) throws SQLException {

			String Sql = "UPDATE orders Set orderStatus=? ,modifiedAt=? where productId=? and id=? ";
			PreparedStatement ps = con.prepareStatement(Sql);
			int i = 0;
			ps.setString(++i, orderStatus);
			ps.setTimestamp(++i, modifiedAt);
			ps.setInt(++i, productId);
			ps.setInt(++i, id);
			System.out.println("update status===>"+ps.toString());
			
			int k=ps.executeUpdate();
			return k;
		}
		
		public List<Orders> getUserOrders(Connection con) throws SQLException {
			List<Orders> orderList = new ArrayList<>();

			Orders o;
			Product p;
			String sql = "SELECT * FROM orders  ord join user u on ord.userId=u.id where u.id=?";

			System.out.println("SQL  select===>" + sql);
			int count = 0;
			int i = 0;
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(++i, userId);
		
			
			System.out.println("sql==========>"+ps.toString());
			
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				o = new Orders();

				o.setId(rs.getInt("id"));
				o.setOrderStatus(rs.getString("orderStatus"));
				o.setPrice(rs.getInt("price"));
				o.setProduct_type(rs.getInt("product_type"));
				o.setProductId(rs.getInt("productId"));
				o.setProductName(rs.getString("product_name"));
				o.setQty(rs.getInt("qty"));
				o.setUserId(rs.getInt("userId"));
				o.setUserName(rs.getString("first_name")+" "+rs.getString("last_name"));
				o.setCreatedAt(rs.getTimestamp("orderAt"));
				o.setModifiedAt(rs.getTimestamp("modifiedAt"));
				orderList.add(o);
			}

			return orderList;
		}

		public Timestamp getModifiedAt() {
			return modifiedAt;
		}

		public void setModifiedAt(Timestamp modifiedAt) {
			this.modifiedAt = modifiedAt;
		}

	}
