package com.RealEState.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.RealEState.database.DbConnection;
import com.RealEState.login.User;
import com.RealEState.model.Cart;
import com.RealEState.model.Orders;
import com.RealEState.model.Product;
import com.RealEState.order.ManageCart;

/**
 * Servlet implementation class ManageOrders
 */
@WebServlet("/ManageOrders")
public class ManageOrders extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	DbConnection dbConnecion;
	User currentuser;

	ManageCart manageCart ;
	
	public ManageOrders() {
		super();
		try {
			con = dbConnecion.getConnection();
			manageCart = new  ManageCart();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====>" + currentuser.getFirstName());
		String action = request.getParameter("action");

		switch (action) {
		case "showOrders":
			showOrdersList(request, response);
			break;
		case "showOrdersList":
			addToOrderAndShoworders(request, response);
			break;
		case "updateOrderStatus":
			updateOrderStatus(request, response);
			break;
			
		case "showOrdersToUser":
			showOrdersToUser(request, response);
			break;
			
		default:

			break;

		}

	}
	private void showOrdersToUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cart c = new Cart();
		c.setUserID(currentuser.getId());
		Orders os= new Orders();
		os.setOrderStatus("I am In");
		os.setUserId(currentuser.getId());
		List<Orders> orderList;
		try {
			orderList = os.getUserOrders(con);
			
			
			request.setAttribute("orders", orderList);
			System.out.println("orderList   ===>"+orderList.size());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		request.getRequestDispatcher("/orderList.jsp").forward(request, response);
		
	}

	private void updateOrderStatus(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String productId = request.getParameter("productId");
		String status = request.getParameter("status");
		String orderId = request.getParameter("orderId");
		Timestamp ts= new Timestamp(System.currentTimeMillis());
		
		
		Orders order = new Orders();
		
		order.setProductId(Integer.parseInt(productId));
		order.setId(Integer.parseInt(orderId));
		order.setOrderStatus(status);
		
		order.setModifiedAt(ts);
		try {
			order.updateOrderStatus(con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====>" + currentuser.getFirstName());
		String action = request.getParameter("action");

		switch (action) {
		case "showOrders":
			showOrdersList(request, response);
			break;

		case "showOrdersList":
			addToOrderAndShoworders(request, response);
			break;
			
			
		default:

			break;

		}

	}

	private void addToOrderAndShoworders(HttpServletRequest request, HttpServletResponse response) {

		try {
			Orders o ;
			Cart c = new Cart();
			c.setUserID(currentuser.getId());
			/*
			 * List<Cart> itemList = c.getCartDetails(con);
			 * 
			 * Product p = new Product();
			 * 
			 * List<Product> productList = p.getProducts(con);
			 * 
			 * for (Cart item : itemList) {
			 * 
			 * for (Product prod : productList) { o= new Orders(); if (item.getProductId()
			 * == prod.getId()) { o.setOrderStatus("In progress");
			 * 
			 * int totalPrice = item.getQty() * prod.getPrice();
			 * 
			 * o.setPrice(totalPrice);
			 * 
			 * o.setUserId(currentuser.getId()); o.setQty(item.getQty());
			 * o.setProduct_type(Integer.parseInt(prod.getProduct_type()));
			 * o.setProductId(item.getProductId());
			 * o.setProductName(prod.getProduct_name()); int inserted=0;
			 * inserted=o.insert(con); System.out.println("inserted===>"+inserted); }
			 * 
			 * }
			 * 
			 * }
			 */
			
			//manageCart.deleteCart(request, response);
			
			Orders os= new Orders();
			
			os.setOrderStatus("I am In");
			os.setUserId(currentuser.getId());
			List<Orders> orderList ;
			if(currentuser.getIsAdmin()==1) {
				orderList =os.getOrders(con);
			}else {
				
				
				orderList = os.getUserOrders(con);
			}
			
			
			request.setAttribute("orders", orderList);
			System.out.println("orderList   ===>"+orderList.size());
			
			request.getRequestDispatcher("/orderList.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
			
		}

	}
	
	
	private void showOrdersList(HttpServletRequest request, HttpServletResponse response) {

		try {
			Orders o ;
			Cart c = new Cart();
			c.setUserID(currentuser.getId());
			List<Cart> itemList = c.getCartDetails(con);

			Product p = new Product();

			List<Product> productList = p.getProducts(con);
			
			
			
			/*
			 * java.util.Date date =new Date(); java.sql.Date sqlPackageDate = new
			 * java.sql.Date(date.getTime());
			 */
 
			
			Timestamp ts= new Timestamp(System.currentTimeMillis());
			
			System.out.println("date===========>"+ts.getTime());
			
			for (Cart item : itemList) {

				for (Product prod : productList) {
					o= new Orders();
					if (item.getProductId() == prod.getId()) {
						o.setOrderStatus("I am In");

						int totalPrice = item.getQty() * prod.getPrice();

					o.setPrice(totalPrice);
					
					o.setUserId(currentuser.getId());
					o.setQty(item.getQty());
					o.setProduct_type(Integer.parseInt(prod.getProduct_type()));
					o.setProductId(item.getProductId());
					o.setProductName(prod.getProduct_name());
					o.setCreatedAt(ts);
					int inserted=0;
					inserted=o.insert(con);		
					System.out.println("inserted===>"+inserted);
					}
					
				}

			}
			
	

			c.setUserID(currentuser.getId());
			
			c.deleteCart(con);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}

	}

}
