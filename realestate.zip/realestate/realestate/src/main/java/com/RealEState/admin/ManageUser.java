package com.RealEState.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.RealEState.admin.ManageProducts;
import com.RealEState.database.DbConnection;
import com.RealEState.login.Info;
import com.RealEState.login.User;

/**
 * Servlet implementation class ManageUser
 */
@WebServlet("/ManageUser")
public class ManageUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	DbConnection dbConnecion;
	User currentuser;

	ManageProducts manageProducts=  new ManageProducts();

	public ManageUser() {
		super();
		try {
			con = dbConnecion.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		switch (action) {
		case "showUserList":
			showUserList(request, response);
			break;

		case "insertUser":

			insertUser(request, response);
			break;

		case "deleteUser":

			deleteUser(request, response);

			break;
			
		case "deleteInfo":

			deleteUser(request, response);

			break;


		case "addUser":
			addUser(request, response);
			break;

		case "updateUser":
			updateUser(request, response);
			break;
		
		case "showUserProfile":
			showUserProfile(request, response);
			break;
			
		case "showInfouser":
			/*
			 * try { showInfouser(request, response); } catch (SQLException |
			 * ServletException | IOException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 */
			try {
				showInfouser(request, response);
			} catch (SQLException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		

		default:

			break;

		}

	}



	private void showInfouser(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		Info info = new Info();
		try {
			List<Info> infoList = info.getInfoList(con);

			request.setAttribute("infoList", infoList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		request.getRequestDispatcher("/ShowInfo.jsp").forward(request, response);

	}


	private void showUserProfile(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("userId"));
		User u = new User();

		u.setId(id);

		try {
			request.setAttribute("users", u.getUserById(con));

			request.getRequestDispatcher("/showUserProfile.jsp").forward(request, response);

		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) {

		int id = Integer.parseInt(request.getParameter("userId"));
		User u = new User();

		u.setId(id);

		try {
			request.setAttribute("users", u.getUserById(con));

			request.getRequestDispatcher("/addUser.jsp").forward(request, response);

		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void addUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.removeAttribute("users");
		request.getRequestDispatcher("/addUser.jsp").forward(request, response);

	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		User user = new User();
		if(request.getParameter("userId")!=null && !request.getParameter("userId").isEmpty()) {
			int id = Integer.parseInt(request.getParameter("userId"));
			user.setId(id);
			}
		List<User> userList;
		try {

			user.delete(con);
			
			userList = user.getUserList(con);
			request.setAttribute("userList", userList);
			RequestDispatcher rd = request.getRequestDispatcher("/userList.jsp");
			rd.forward(request, response);
		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * private void deleteInfo(HttpServletRequest request, HttpServletResponse
	 * response) { // TODO Auto-generated method stub Info info = new Info();
	 * if(request.getParameter("id")!=null && !request.getParameter("id").isEmpty())
	 * { int id = Integer.parseInt(request.getParameter("id")); info.setId(id); }
	 * List<Info> infoList; try {
	 * 
	 * info.deleteInfo(con);
	 * 
	 * infoList = info.getInfoList(con); request.setAttribute("infoList", infoList);
	 * RequestDispatcher rd = request.getRequestDispatcher("/ShowInfo.jsp");
	 * rd.forward(request, response); } catch (SQLException | ServletException |
	 * IOException e) { // TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * 
	 * 
	 * }
	 */

	private void insertUser(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		int profile = Integer.parseInt(request.getParameter("profile"));
		
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String email = request.getParameter("email");
		String password = request.getParameter("pwd");

		String address = request.getParameter("address");
		String state = request.getParameter("state");
		String mobileNo = request.getParameter("mobile_number");
		
		int flag =0; 
		int isAdmin=0;
				
		if(request.getParameterMap().containsKey("isAdmin")) {
		isAdmin=Integer.parseInt(request.getParameter("isAdmin"));
		flag=1;
		}

		System.out.println(firstName + "====" + lastName + "=====" + email + "======" + password + "===" + address
				+ "==========" + state);
		
		
		
		
		User user = new User();
		
		if(request.getParameter("userId")!=null && !request.getParameter("userId").isEmpty()) {
		int id = Integer.parseInt(request.getParameter("userId"));
		user.setId(id);
		}

		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setAddress(address);
		user.setEmail(email);
		user.setMobileNo(Long.valueOf(mobileNo));
		user.setIsAdmin(isAdmin);

		user.setPassword(password);
		user.setState(state);
		try {
			System.out.println("user.getId()===>"+user.getId());
			if(user.getId()==0) {
				
				
			int inserted = user.insert(con);
			System.out.println("inserted" + inserted);
			}
			if(user.getId()>0) {
			
				user.update(con);
			}
			
			List<User> userList = user.getUserList(con);

			request.setAttribute("userList", userList);
			RequestDispatcher rd ;
			if(profile==0) {
			 rd = request.getRequestDispatcher("/userList.jsp");
			 rd.forward(request, response);
			}if(profile==1) {
				manageProducts.showProductListForUser(request, response);
		}

			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	private void showUserList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		User user = new User();
		try {
			List<User> userList = user.getUserList(con);

			request.setAttribute("userList", userList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		request.getRequestDispatcher("/userList.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession();
		currentuser = (User) session.getAttribute("user");

		System.out.println("user====>" + currentuser.getFirstName());
		String action = request.getParameter("action");
		doGet(request, response);
	}

}
