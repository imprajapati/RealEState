package com.RealEState.login;

public class Logout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
