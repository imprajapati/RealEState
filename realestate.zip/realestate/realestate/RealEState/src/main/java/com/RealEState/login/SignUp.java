package com.RealEState.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RealEState.database.DbConnection;
import com.RealEState.login.Login;

@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection  con;
	
	DbConnection  dbConnecion;
	
    public SignUp()  {
        super();
        try {
			con = DbConnection.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


String firstName =  request.getParameter("fname");		
String lastName =  request.getParameter("lname");
String email =  request.getParameter("email");
String password =  request.getParameter("pwd");

String address =  request.getParameter("address");
String state =  request.getParameter("state");
String mobileNo =  request.getParameter("mobile_number");


System.out.println(firstName+"===="+lastName+"====="+email+"======"+password+"==="+address+"=========="+state);
User user = new User();

user.setFirstName(firstName);
user.setLastName(lastName);
user.setAddress(address);
user.setEmail(email);
user.setMobileNo(Long.valueOf(mobileNo));

user.setPassword(password);
user.setState(state);
try {
int inserted =user.insert(con);

System.out.println("inserted"+inserted);


RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");

rd.forward(request, response);
	

}catch (Exception e) {
	// TODO: handle exception
}

	}

}
