package com.RealEState.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com..admin.ManageProducts;
//import com.RealEState.admin.ManageProducts;
import com.RealEState.database.DbConnection;
//import com.RealEState.model.Product;
import com.mysql.cj.Session;




	@WebServlet("/Login")
	public class Login extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
		Connection con;
		//ManageProducts manageProducts=  new ManageProducts();

		DbConnection dbConnecion;
	    public Login() {
	        super();
	        try {
				con = DbConnection.getConnection();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        // TODO Auto-generated constructor stub
	    }
	

		/**
		 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			String email =  request.getParameter("email");
			String password =  request.getParameter("pwd");
			
			User user= new User();
			
			user.setEmail(email);
			user.setPassword(password);
			
		try {
			boolean validated=	user.validateUser(con);
			
			System.out.println("validated===>"+validated);
			 HttpSession session = request.getSession(true);
			if(validated) {
				
				User currentuser = user.getUser(con);
				
				
				 session.setAttribute("user",currentuser);
				
				System.out.println("currentuser=="+currentuser.getFirstName());
				
				//manageProducts.showProductListForUser(request, response);
				
				
			
				
			}else {

				System.out.println("Invalid user");
				   session.invalidate();
				   
				   request.setAttribute("errormsg", "Invalid user name or password");
				
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				
				rd.forward(request, response);
				
			}
			
			
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			
			
			
		}
	}
	


		
	

